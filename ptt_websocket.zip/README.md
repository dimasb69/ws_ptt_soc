Servidor FastAPI para manejar WebSockets 

Por defecto está para usar la ip que necesites y el puerto 8000

recuerda crear el environment antes de importar los requirements.txt y un git para guardar tus cambios

