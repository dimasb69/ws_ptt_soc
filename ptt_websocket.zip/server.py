from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict, List, Optional # Asegúrate de tener Optional
import json
# import asyncio # No parece usarse directamente, pero puede ser útil para otras tareas
import os
import base64
import uuid # Para IDs únicos
import aiofiles # Para escritura de archivos asíncrona

app = FastAPI()

# --- Configuración ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "audio_uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ConnectionManager:
    def __init__(self):
        # El diccionario ahora almacenará más información por cliente
        self.active_connections: Dict[str, Dict[str, any]] = {}
        self.current_transmitter: Optional[str] = None # Usar Optional para claridad
        self.audio_messages_metadata: Dict[str, Dict[str, str]] = {}

    async def connect(self, websocket: WebSocket, client_id: str, username: str):
        await websocket.accept()
        # NUEVO: Añadir estado de 'listo para recibir'
        self.active_connections[client_id] = {
            "websocket": websocket,
            "username": username,
            "is_ready_to_receive": True # Nuevo estado, True por defecto
        }
        print(f"Cliente conectado: {client_id} ({username}). Ready: True. Total: {len(self.active_connections)}")

    def disconnect(self, client_id: str) -> str: # Especificar tipo de retorno
        disconnected_user_info = self.active_connections.pop(client_id, None)
        username = disconnected_user_info["username"] if disconnected_user_info else "Desconocido"

        if self.current_transmitter == client_id:
            print(f"INFO: El transmisor actual '{username}' ({client_id}) se desconectó. Limpiando current_transmitter.")
            self.current_transmitter = None
            # El broadcast de transmit_stopped se maneja en el finally del endpoint

        print(f"Cliente desconectado: {client_id} ({username}). Total: {len(self.active_connections)}")
        return username

    # NUEVO: Método para cambiar el estado del cliente a ocupado
    def set_client_busy(self, client_id: str):
        connection_info = self.active_connections.get(client_id)
        if connection_info:
            connection_info["is_ready_to_receive"] = False
            print(f"ESTADO: Cliente '{connection_info['username']}' ({client_id}) ahora está OCUPADO.")
        else:
            print(f"ADVERTENCIA_ESTADO: Intento de poner ocupado a cliente no encontrado: {client_id}")

    # NUEVO: Método para cambiar el estado del cliente a listo
    def set_client_ready(self, client_id: str):
        connection_info = self.active_connections.get(client_id)
        if connection_info:
            connection_info["is_ready_to_receive"] = True
            print(f"ESTADO: Cliente '{connection_info['username']}' ({client_id}) ahora está LISTO.")
        else:
            print(f"ADVERTENCIA_ESTADO: Intento de poner listo a cliente no encontrado: {client_id}")

    # NUEVO: Método para verificar si todos los OTROS clientes están listos
    def are_all_other_clients_ready(self, requesting_client_id: str) -> bool:
        if len(self.active_connections) <= 1: # Si solo está el solicitante o nadie más
            return True

        for client_id_loop, connection_info in self.active_connections.items():
            if client_id_loop != requesting_client_id: # No chequear al que solicita
                if not connection_info.get("is_ready_to_receive", True): # Default a True si falta por alguna razón
                    print(f"VERIFICACIÓN_LISTOS: Cliente '{connection_info['username']}' ({client_id_loop}) NO está listo.")
                    return False
        print(f"VERIFICACIÓN_LISTOS: Todos los demás clientes están listos para el solicitante {requesting_client_id}.")
        return True

    async def send_personal_message(self, message: dict, client_id: str):
        # ... (sin cambios)
        connection_info = self.active_connections.get(client_id)
        if connection_info and connection_info.get("websocket"):
            websocket = connection_info["websocket"]
            try:
                await websocket.send_json(message)
            except Exception as e:
                print(f"Error enviando mensaje personal a {client_id}: {e}")


    async def broadcast(self, message: dict, exclude_client_id: Optional[str] = None): # Usar Optional
        # ... (sin cambios en la lógica, solo para asegurar que maneje la nueva estructura si es necesario)
        active_client_ids_for_log = list(self.active_connections.keys())
        # print(f"DEBUG_BROADCAST: Iniciando broadcast. Conexiones activas: {active_client_ids_for_log}, Excluyendo: {exclude_client_id}, Mensaje tipo: {message.get('type')}")
        if not self.active_connections:
            # print("DEBUG_BROADCAST: No hay conexiones activas para hacer broadcast.")
            return

        # Crear una copia de los items para iterar de forma segura si hay modificaciones concurrentes (aunque no debería en este flujo síncrono por cliente)
        for client_id_loop, connection_info in list(self.active_connections.items()):
            if exclude_client_id and client_id_loop == exclude_client_id:
                continue

            websocket = connection_info.get("websocket")
            if websocket:
                try:
                    # print(f"SERVIDOR_BROADCAST: Intentando enviar a '{client_id_loop}' ({connection_info.get('username', 'N/A')}) (mensaje tipo: {message.get('type')})")
                    await websocket.send_json(message)
                except Exception as e:
                    print(f"Error enviando (broadcast) a {client_id_loop}: {e}.")


manager = ConnectionManager()

@app.websocket("/ws/{client_id}/{username}")
async def websocket_endpoint(websocket: WebSocket, client_id: str, username: str):
    await manager.connect(websocket, client_id, username)
    # disconnected_username se usa en el finally, así que está bien mantenerlo
    disconnected_username = username

    try:
        while True:
            try:
                data = await websocket.receive_json()
            except WebSocketDisconnect:
                print(f"INFO: WebSocketDisconnect (receive_json) para {client_id} ({username})")
                break
            except Exception as e:
                print(f"Error recibiendo JSON de {client_id} ({username}): {e}. Cerrando conexión.")
                break

            msg_type = data.get("type")
            print(f"SERVIDOR_RECV ({username}): Tipo='{msg_type}', Data parcial: { {k:v for k,v in data.items() if k != 'data'} }")


            if msg_type == "request_transmit":
                print(f"SERVIDOR_REQUEST_TRANSMIT: Solicitud de '{username}' ({client_id}). Transmisor actual: {manager.current_transmitter}")
                if manager.current_transmitter is not None:
                    # Si ya hay un transmisor, denegar.
                    current_transmitter_username_busy = manager.active_connections.get(manager.current_transmitter, {}).get("username", "Otro usuario")
                    print(f"SERVIDOR_REQUEST_TRANSMIT: '{username}' ({client_id}) DENEGADO (ocupado por '{current_transmitter_username_busy}' ({manager.current_transmitter})).")
                    await manager.send_personal_message({ "type": "transmit_denied", "reason": f"Canal ocupado por {current_transmitter_username_busy}" }, client_id)

                # NUEVA VERIFICACIÓN: ¿Están todos los demás listos?
                elif not manager.are_all_other_clients_ready(client_id):
                    print(f"SERVIDOR_REQUEST_TRANSMIT: '{username}' ({client_id}) DENEGADO (receptores ocupados).")
                    await manager.send_personal_message({ "type": "transmit_denied", "reason": "Uno o más receptores están ocupados" }, client_id)

                else:
                    # Canal libre y todos los demás listos, APROBAR.
                    manager.current_transmitter = client_id
                    current_transmitter_username = manager.active_connections.get(client_id, {}).get("username", "Desconocido")
                    print(f"SERVIDOR_REQUEST_TRANSMIT: '{current_transmitter_username}' ({client_id}) APROBADO para transmitir.")

                    # Notificar al solicitante que fue aprobado
                    await manager.send_personal_message({"type": "transmit_approved"}, client_id)

                    # Notificar a TODOS (incluido el nuevo transmisor) que la transmisión ha comenzado
                    await manager.broadcast({
                        "type": "transmit_started",
                        "client_id": client_id,
                        "username": current_transmitter_username
                    })

            elif msg_type == "stop_transmit":
                # ... (sin cambios significativos) ...
                print(f"SERVIDOR_STOP_TRANSMIT: Solicitud de '{username}' ({client_id}). Transmisor actual: {manager.current_transmitter}")
                if manager.current_transmitter == client_id:
                    manager.current_transmitter = None
                    stopped_username = manager.active_connections.get(client_id, {}).get("username", "Desconocido")
                    print(f"SERVIDOR_STOP_TRANSMIT: '{stopped_username}' ({client_id}) DETUVO la transmisión.")
                    await manager.broadcast({
                        "type": "transmit_stopped",
                        "client_id": client_id,
                        "username": stopped_username
                    })
                else:
                    print(f"SERVIDOR_STOP_TRANSMIT: '{username}' ({client_id}) intentó detener, pero no era el transmisor ({manager.current_transmitter}).")


            elif msg_type == "new_audio_message":
                # ... (sin cambios significativos en la lógica de guardado y broadcast de 'incoming_audio_message') ...
                print(f"SERVIDOR_NEW_AUDIO: Recibido 'new_audio_message' de '{username}' ({client_id}).")
                base64_data = data.get("data")
                original_filename = data.get("filename", "audio.aac")
                content_type = data.get("content_type", "audio/aac")

                if not base64_data:
                    print(f"SERVIDOR_ERROR: 'new_audio_message' de {client_id} no contenía 'data'.")
                    continue
                try:
                    audio_bytes = base64.b64decode(base64_data)
                except Exception as e:
                    print(f"SERVIDOR_ERROR: Error decodificando Base64 de {client_id}: {e}")
                    continue

                message_id = str(uuid.uuid4())
                file_extension = os.path.splitext(original_filename)[1] if os.path.splitext(original_filename)[1] else ".aac"
                server_filename = f"{message_id}{file_extension}"
                file_path = os.path.join(UPLOAD_FOLDER, server_filename)

                try:
                    async with aiofiles.open(file_path, "wb") as f:
                        await f.write(audio_bytes)
                    print(f"SERVIDOR_NEW_AUDIO: Archivo '{server_filename}' guardado para msg {message_id}.")
                    manager.audio_messages_metadata[message_id] = {
                        "filepath": file_path, "filename": original_filename,
                        "content_type": content_type, "sender_username": username,
                        "sender_client_id": client_id
                    }
                    await manager.broadcast({
                        "type": "incoming_audio_message", "message_id": message_id,
                        "sender_client_id": client_id, "sender_username": username,
                        "filename": original_filename, "content_type": content_type
                    }, exclude_client_id=client_id)
                except Exception as e:
                    print(f"SERVIDOR_ERROR: Error guardando archivo para {client_id}: {e}")

            # NUEVOS TIPOS DE MENSAJE PARA ESTADO DEL RECEPTOR
            elif msg_type == "receiver_busy":
                # El cliente que envía este mensaje es el que está ocupado.
                # El client_id en el payload es para confirmar, pero confiamos en el client_id de la conexión.
                message_client_id = data.get("client_id")
                if message_client_id == client_id:
                    manager.set_client_busy(client_id)
                else:
                    print(f"ADVERTENCIA: 'receiver_busy' de {username} ({client_id}) con payload client_id {message_client_id} no coincide.")

            elif msg_type == "receiver_ready":
                message_client_id = data.get("client_id")
                status_from_client = data.get("status", "unknown")
                if message_client_id == client_id:
                    manager.set_client_ready(client_id)
                    print(f"ESTADO_CLIENTE: '{username}' ({client_id}) informó 'receiver_ready', status: {status_from_client}")
                else:
                    print(f"ADVERTENCIA: 'receiver_ready' de {username} ({client_id}) con payload client_id {message_client_id} no coincide.")


            elif msg_type == "ping":
                # ... (sin cambios) ...
                await manager.send_personal_message({"type": "pong"}, client_id)
            else:
                print(f"SERVIDOR: Tipo DESCONOCIDO de '{username}' ({client_id}): '{msg_type}'.")

    except WebSocketDisconnect:
        # Esto se captura si el cliente se desconecta abruptamente o si el bucle se rompe
        print(f"SERVIDOR_EXCEPTION_WS_DISCONNECT: WebSocketDisconnect (exterior) para {client_id} ({disconnected_username})")
    except Exception as e:
        print(f"SERVIDOR_EXCEPTION_BUCLE: Excepción INESPERADA en bucle para {client_id} ({disconnected_username}): {e.__class__.__name__} - {e}")
    finally:
        print(f"SERVIDOR_FINALLY: Limpieza para {client_id} ({disconnected_username}). Transmisor ANTES: {manager.current_transmitter}")
        was_transmitter = (manager.current_transmitter == client_id)

        # Guardar el nombre de usuario antes de que disconnect() lo elimine potencialmente
        final_username_for_broadcast = manager.active_connections.get(client_id, {}).get("username", disconnected_username)

        manager.disconnect(client_id) # Elimina de active_connections y limpia current_transmitter si era él

        if was_transmitter: # Si el cliente que se desconectó ERA el transmisor
            print(f"SERVIDOR_FINALLY: El transmisor '{final_username_for_broadcast}' ({client_id}) se desconectó. Notificando 'transmit_stopped'.")
            # manager.current_transmitter ya debería ser None por el disconnect()
            await manager.broadcast({ # Notificar a los restantes
                "type": "transmit_stopped",
                "client_id": client_id,
                "username": final_username_for_broadcast
            }) # No excluir a nadie aquí, ya que el que se desconectó ya no está en la lista para recibir

        # Si el cliente se desconecta y estaba 'busy', ya no importa para la comprobación
        # 'are_all_other_clients_ready' porque ya no está en 'active_connections'.
        print(f"SERVIDOR_FINALLY: Limpieza completa para {client_id} ({final_username_for_broadcast}). Transmisor DESPUÉS: {manager.current_transmitter}")


# --- Endpoint HTTP para descargar archivos (sin cambios) ---
@app.get("/audio/{message_id}/{filename_from_client}")
async def download_audio(message_id: str, filename_from_client: str):
    # ... (sin cambios)
    print(f"SERVIDOR_DOWNLOAD: Solicitud descarga para message_id: {message_id}, filename (cliente): {filename_from_client}")
    metadata = manager.audio_messages_metadata.get(message_id)
    if not metadata:
        print(f"SERVIDOR_DOWNLOAD_ERROR: Metadatos no encontrados para message_id: {message_id}")
        raise HTTPException(status_code=404, detail="Audio message metadata not found")

    file_path_on_server = metadata.get("filepath")
    original_filename_for_download = metadata.get("filename", "audio_message.aac")
    content_type = metadata.get("content_type", "application/octet-stream")

    if not file_path_on_server or not os.path.exists(file_path_on_server):
        print(f"SERVIDOR_DOWNLOAD_ERROR: Archivo no encontrado para message_id: {message_id}. Ruta: {file_path_on_server}")
        raise HTTPException(status_code=404, detail="Audio file not found on server")

    print(f"SERVIDOR_DOWNLOAD: Sirviendo '{file_path_on_server}' como '{original_filename_for_download}' tipo '{content_type}'")
    return FileResponse(path=file_path_on_server, filename=original_filename_for_download, media_type=content_type)

